const sqlite3 = require("sqlite3").verbose();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const db = new sqlite3.Database("./notes.db", sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
    if (err) return console.error(err.message);
    console.log("Connected to the notes database.");
});

const secretKey = "fhfkrmeijnfjiejejjndkwqeoaoiei";

// Create tables if they don't exist
const sqlCreateUsers = `
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        password TEXT
    )
`;

const sqlCreateTodos = `
    CREATE TABLE IF NOT EXISTS todo (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        description TEXT,
        status TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )
`;

db.serialize(() => {
    db.run(sqlCreateUsers);
    db.run(sqlCreateTodos);
});

// Register user function
function registerUser(req, res) {
    const { username, password } = req.body;
    const salt = bcrypt.genSaltSync(10);
    const hashedPassword = bcrypt.hashSync(password, salt);

    const sql = 'INSERT INTO users (username, password) VALUES (?, ?)';
    db.run(sql, [username, hashedPassword], (err) => {
        if (err) {
            return res.status(500).send({ message: err.message });
        }
        res.status(201).send({ message: "User registered successfully" });
    });
}

// Login user function
function loginUser(req, res) {
    const { username, password } = req.body;

    const sql = 'SELECT * FROM users WHERE username = ?';
    db.get(sql, [username], (err, row) => {
        if (err) {
            return res.status(500).send({ message: err.message });
        } else if (row) {
            const hashedPassword = row.password;
            if (bcrypt.compareSync(password, hashedPassword)) {
                const token = jwt.sign({ id: row.id, username: row.username }, secretKey, { expiresIn: '1h' });
                res.status(200).send({ message: "Login successful", token });
            } else {
                res.status(401).send({ message: "Incorrect password" });
            }
        } else {
            res.status(404).send({ message: "User not found" });
        }
    });
}

// Middleware to authenticate JWT
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.sendStatus(401);

    jwt.verify(token, secretKey, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
}

// Add a new todo function
function addTodo(req, res) {
    const { description, status } = req.body;
    const sql = 'INSERT INTO todo (user_id, description, status) VALUES (?, ?, ?)';
    db.run(sql, [req.user.id, description, status], (err) => {
        if (err) {
            return res.status(500).send({ message: err.message });
        }
        res.status(201).send({ message: "Todo item created successfully" });
    });
}

// Get all todos function
function getTodos(req, res) {
    const sql = 'SELECT * FROM todo WHERE user_id = ?';
    db.all(sql, [req.user.id], (err, rows) => {
        if (err) {
            return res.status(500).send({ message: err.message });
        }
        res.status(200).send(rows);
    });
}

// Update a todo function
function updateTodo(req, res) {
    const { id } = req.params;
    const { description, status } = req.body;

    const sql = 'UPDATE todo SET description = ?, status = ? WHERE id = ? AND user_id = ?';
    db.run(sql, [description, status, id, req.user.id], function(err) {
        if (err) {
            return res.status(500).send({ message: err.message });
        } else if (this.changes === 0) {
            return res.status(404).send({ message: "Todo item not found" });
        }
        res.status(200).send({ message: "Todo item updated successfully" });
    });
}

// Delete a todo function
function deleteTodo(req, res) {
    const { id } = req.params;

    const sql = 'DELETE FROM todo WHERE id = ? AND user_id = ?';
    db.run(sql, [id, req.user.id], function(err) {
        if (err) {
            return res.status(500).send({ message: err.message });
        } else if (this.changes === 0) {
            return res.status(404).send({ message: "Todo item not found" });
        }
        res.status(200).send({ message: "Todo item deleted successfully" });
    });
}

// Get all notes function
function getNotes() {
    return new Promise((resolve, reject) => {
        const sql = 'SELECT * FROM todo';
        db.all(sql, [], (err, rows) => {
            if (err) {
                reject(err);
            } else {
                resolve(rows);
            }
        });
    });
}

// Get note by ID function
function getNoteById(id) {
    return new Promise((resolve, reject) => {
        const sql = 'SELECT * FROM todo WHERE id = ?';
        db.get(sql, [id], (err, row) => {
            if (err) {
                reject(err);
            } else {
                resolve(row);
            }
        });
    });
}

module.exports = {
    registerUser,
    loginUser,
    addTodo,
    getTodos,
    updateTodo,
    deleteTodo,
    getNotes,
    getNoteById,
    authenticateToken
};

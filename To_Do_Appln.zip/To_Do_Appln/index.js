// app.js
const express = require('express');
const { 
    registerUser, 
    loginUser, 
    addTodo, 
    getTodos, 
    updateTodo, 
    deleteTodo, 
    getNotes, 
    getNoteById, 
    authenticateToken 
} = require('./models/database');

const app = express();

app.use(express.json()); // Middleware to parse JSON bodies

// Routes
app.get('/', (req, res) => {
    res.send('Hello, World!');
});

app.post('/register', registerUser);

app.post('/login', loginUser);

app.post('/todos', authenticateToken, addTodo);

app.get('/todos', authenticateToken, getTodos);

app.put('/todos/:id', authenticateToken, updateTodo);

app.delete('/todos/:id', authenticateToken, deleteTodo);

app.get('/notes', authenticateToken, getNotes);

app.get('/notes/:id', authenticateToken, getNoteById);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

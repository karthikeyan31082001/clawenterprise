const sqlite3 = require("sqlite3").verbose();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 5000;

const db = new sqlite3.Database("./notes.db", sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
    if (err) return console.error(err.message);
    console.log("Connected to the notes database.");
});
const secretKey = "fhfkrmeijnfjiejejjndkwqeoaoiei";
let sql = 'CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)';
let sql2 = 'CREATE TABLE IF NOT EXISTS todo(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, description TEXT, status TEXT, FOREIGN KEY(user_id) REFERENCES users(id))';

db.serialize(() => {
    db.run(sql, (err) => {
        if (err) {
            console.error(err.message);
        } else {
            console.log("Users table created.");
        }
    });

db.run(sql2, (err) => {
    if (err) {
        console.error(err.message);
    } else {
        console.log("To-do table created.");
    }
    });
});

// selecte statement
function select_all_todo()
{
    let b_todo = 'SELECT * FROM todo';
    db.all(b_todo,[],(err,rows)=>{
        if(err) {
            console.error(err.message);
        }
        else{
            rows.forEach((row) => {
                console.log(row);   
            });
        }
    })
}
function select_all_users() {
    let b = 'SELECT * FROM users';
    db.all(b, [], (err, rows) => {
        if (err) {
            console.error(err.message);
        } else {
                rows.forEach((row) => {
                console.log(row);   
            });
        }
    });

            }

function fetch_allnotes(user_id)
{
    let all_notes = 'select * from todo WHERE user_id = user_id';
    db.all(all_notes, [], (err, rows) => {
        if (err) {
            console.error(err.message);
        } else {
                rows.forEach((row) => {
                console.log(row);   
            });
        }
    });


    }  
// Login Registration function
function register(username, password) {
    const sqlins = 'INSERT INTO users (username, password) VALUES (?, ?)';
    const salt = bcrypt.genSaltSync(10);
    const hashedPassword = bcrypt.hashSync(password, salt);

    
    db.run(sqlins, [username, hashedPassword], (err) => {
        if (err) {
            console.error(err.message);
        } else {
            console.log("User registered successfully.");
            select_all_users();
            }
        });

        }

// Login function
function login(username, password) {
    salt = bcrypt.genSaltSync(10);

    const sqlget = 'SELECT * FROM users WHERE username = ?';
    db.get(sqlget, [username], (err, row) => {
        if (err) {
            console.error(err.message);
        } else if (row) {
            const hashedPassword = row.password;
            if (bcrypt.compareSync(password, hashedPassword)) {
                const token = jwt.sign({ id: row.id, username: row.username }, secretKey, { expiresIn: '1h' });
                console.log("Login successful.");
                console.log("JWT Token:", token);
            } else {
                console.log("Incorrect password.");
            }
        } else {
            console.log("User not found.");
        }
    });
}

// insert
function insertnotes_todo(userid,description,status)
{   
    const insert_into_todo = 'INSERT into todo (user_id,description,status) VALUES(?,?,?)';
    // ? ? is a wilcard character if value is null then it is used 


    db.run(insert_into_todo, [userid,description,status], (err) => {
        if (err) {
            console.error(err.message);
        } else {
            console.log("User added a note successfully.");
            
            }
        });
        select_all_todo();
        }


// update
function Update_description(id,userid,newdescription)
{

    const sql_update_desc = 'update todo SET description = ? where user_id = ? and id = ?';

    db.run(sql_update_desc,[newdescription,userid,id],function(err){
            if(err){
                console.error(err.message);
            }
            else{
                console.log('User'+userid +'update the description');
            }
        
    });
}

function Update_status(id,userid,status)
{

    const sql_update_status = 'update todo SET status = ? where user_id = ? and id = ?';

    db.run(sql_update_desc,[status,userid,id],function(err){
        if(err){
            console.error(err.message);
        }
        else{
            console.log('User'+userid +'update the status');
        }
    
});

}

// delete a row in todo
function delete_note_todo(id,userid)
{
    const deleteidNote = 'DELETE from todo where id=? and user_id = ?';
    db.run(deleteidNote,[id,userid],function(err){
        if(err){
            console.error(err.message);
        }
        else{
            console.log(`Note with ID ${id} for user ${userid} deleted.`);
        }
    })
}

// JWT Middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.sendStatus(401);

    jwt.verify(token, secretKey, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
}


//register('admin', 'poda');
//login('admin', 'admin');
//insertnotes_todo(1,"hey excuse who is hey ","alive")

//insertnotes_todo(1,"mirace ","died")
//register('wheamstone','uknowme')
//login('wheamstone', 'uknowme');
//select_all_users();
//Update_description(2,1, 'hey there from mars');
//delete_note_todo(30);
//insertnotes_todo(30,"uio","uio");

//delete_note_todo(4,30)

// select_all_todo();

// Ensure the database connection is properly closed
db.close((err) => {
    if (err) {
        console.error(err.message);
    } else {
        console.log("Closed the database connection.");
    }
});


//  Function Update_description updates the description with id(which notes) and user id as parameter 
//  Function Update_status updates the status with id(which notes) and user id as parameter 
//  Function select_all_users print total rows 
//  Function select_all_todo print total rows from todo table 
//  Function fetch_allnotes prints all notes from specific user_id from todo table 
// Function insertnotes_todo asks(userid,description,status) to insert new rows 
// Function delete_note_todo(id,userid) deletes by inputting id and user id 